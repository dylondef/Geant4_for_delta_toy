#ifndef SteppingAction_h
#define SteppingAction_h

#include "G4UserSteppingAction.hh"
#include "G4Step.hh"
#include "CherenkovAnalyzer.hh"
#include <map>

class EventAction;

class SteppingAction : public G4UserSteppingAction
{
public:
    SteppingAction(EventAction* eventAction);
    ~SteppingAction() override = default;

    void UserSteppingAction(const G4Step*) override;

    // Called by EventAction::BeginOfEventAction to reset per-event state
    void ClearEvent() {
        fCherCumul.clear();
        fTrackLen.clear();
        fStepCount.clear();
    }

private:
    EventAction*      fEventAction;
    CherenkovAnalyzer fCher;

    // Per-track accumulators: track_id -> cumulative value
    std::map<int,double> fCherCumul;    // Cherenkov photon count
    std::map<int,double> fTrackLen;     // track length [mm]
    std::map<int,int>    fStepCount;    // step counter
};

#endif
