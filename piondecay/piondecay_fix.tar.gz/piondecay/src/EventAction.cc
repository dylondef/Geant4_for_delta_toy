#include "EventAction.hh"
#include "RunAction.hh"
#include "SteppingAction.hh"
#include "G4Event.hh"

EventAction::EventAction(RunAction* runAction)
: G4UserEventAction(), fRunAction(runAction)
{}

void EventAction::BeginOfEventAction(const G4Event* event)
{
    fSteps.clear();
    fHasSummary  = false;
    fSummary     = EventSummary{};

    // Set event ID from Geant4 event number (fixes event_id always = 0)
    fSummary.event_id = event->GetEventID();

    // Clear per-track stepping accumulators (fixes track_len not resetting)
    if (fSteppingAction)
        fSteppingAction->ClearEvent();
}

void EventAction::EndOfEventAction(const G4Event*)
{
    for (const auto& s : fSteps)
        fRunAction->FillStepTree(s);

    if (fHasSummary) {
        fSummary.total_cher = fSummary.pi_cher_total
                            + fSummary.mu_cher_total
                            + fSummary.e_cher_total;
        fRunAction->FillEventTree(fSummary);
    }
}
