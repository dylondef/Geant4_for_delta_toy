#include "PrimaryGeneratorAction.hh"
#include "EventAction.hh"

#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "G4SystemOfUnits.hh"
#include "G4PhysicalConstants.hh"
#include "G4Event.hh"

PrimaryGeneratorAction::PrimaryGeneratorAction(EventAction* eventAction)
: G4VUserPrimaryGeneratorAction(), fEventAction(eventAction)
{
    fParticleGun = new G4ParticleGun(1);

    // pi+ definition
    G4ParticleTable* pt = G4ParticleTable::GetParticleTable();
    fParticleGun->SetParticleDefinition(pt->FindParticle("pi+"));

    // Fixed start position: center of water sphere
    // This represents the nucleus position (O-16 in water)
    fParticleGun->SetParticlePosition(G4ThreeVector(0, 0, 0));

    // Load momentum CSV
    // Look for it in the current directory, then one level up
    fMomReader = new MomentumReader("../pip_momenta_geant4.csv");
    if (!fMomReader->IsValid()) {
        delete fMomReader;
        fMomReader = new MomentumReader("pip_momenta_geant4.csv");
    }
    if (!fMomReader->IsValid()) {
        G4cerr << "[PrimaryGenerator] WARNING: CSV not found! "
               << "Using fallback 300 MeV/c\n";
    }
}

PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
    delete fParticleGun;
    delete fMomReader;
}

void PrimaryGeneratorAction::GeneratePrimaries(G4Event* event)
{
    double KE_GeV = 0.300;  // fallback 300 MeV kinetic energy
    double px = 0, py = 0, pz = 1.0;

    if (fMomReader && fMomReader->IsValid()) {
        const PionMomentum& pm = fMomReader->GetEntry(fEventCount);
        KE_GeV = pm.KE;
        // Direction from momentum components (all +Z in our CSV)
        double p = pm.p_mag;
        px = pm.px / p;
        py = pm.py / p;
        pz = pm.pz / p;
    }

    fParticleGun->SetParticleMomentumDirection(G4ThreeVector(px, py, pz));
    fParticleGun->SetParticleEnergy(KE_GeV * GeV);
    fParticleGun->GeneratePrimaryVertex(event);

    // Store initial pion momentum in event summary
    // event_id is already set correctly by BeginOfEventAction
    auto& sum = fEventAction->GetSummary();
    double p_mag = (fMomReader && fMomReader->IsValid()) ?
                    fMomReader->GetEntry(fEventCount).p_mag : KE_GeV;
    sum.pi_px0 = px * p_mag;
    sum.pi_py0 = py * p_mag;
    sum.pi_pz0 = pz * p_mag;
    sum.pi_p0  = p_mag;
    sum.pi_KE0 = KE_GeV;
    fEventAction->RecordEvent(sum);

    ++fEventCount;
}
