#include "SteppingAction.hh"
#include "EventAction.hh"
#include "EventData.hh"

#include "G4Step.hh"
#include "G4Track.hh"
#include "G4ParticleDefinition.hh"
#include "G4SystemOfUnits.hh"
#include "G4PhysicalConstants.hh"
#include "G4VProcess.hh"

#include <cstring>
#include <cmath>

SteppingAction::SteppingAction(EventAction* eventAction)
: G4UserSteppingAction(), fEventAction(eventAction)
{}

void SteppingAction::UserSteppingAction(const G4Step* step)
{
    const G4Track* track = step->GetTrack();
    const auto*    pd    = track->GetParticleDefinition();
    const G4String& pname = pd->GetParticleName();

    // ── Only track pi+, mu+, and Michel e+ ───────────────────────────────────
    // For e+ we only want the Michel positron (from mu+ decay, parentID > 0)
    bool is_pi  = (pname == "pi+");
    bool is_mu  = (pname == "mu+");
    bool is_e   = (pname == "e+" && track->GetParentID() > 0);

    if (!is_pi && !is_mu && !is_e) return;

    // ── Gather step kinematics ────────────────────────────────────────────────
    int    trkId    = track->GetTrackID();
    // event_id is set correctly in BeginOfEventAction from G4Event::GetEventID()
    const G4ThreeVector& pos  = step->GetPostStepPoint()->GetPosition();
    const G4ThreeVector& mom  = step->GetPostStepPoint()->GetMomentum();
    double KE      = step->GetPostStepPoint()->GetKineticEnergy() / GeV;
    double edep    = step->GetTotalEnergyDeposit() / GeV;
    double stepLen = step->GetStepLength() / mm;
    double gtime   = step->GetPostStepPoint()->GetGlobalTime() / ns;
    double mass    = pd->GetPDGMass() / GeV;
    double p_mag   = mom.mag() / GeV;
    double E_tot   = KE + mass;
    double beta    = (E_tot > 0) ? p_mag / E_tot : 0.0;
    double gamma_v = (beta < 1.0 && beta > 0.0) ?
                     1.0 / std::sqrt(1.0 - beta*beta) : 1.0;

    // Charge
    int charge_z = static_cast<int>(std::round(pd->GetPDGCharge()));

    // ── Frank-Tamm Cherenkov ──────────────────────────────────────────────────
    double cher_this = 0.0;
    if (beta > CherenkovAnalyzer::BetaThreshold() && stepLen > 0.0) {
        cher_this = fCher.ComputePhotonCount(beta, charge_z, stepLen);
    }

    // Accumulate per-track
    fCherCumul[trkId]  += cher_this;
    fTrackLen[trkId]   += stepLen;
    fStepCount[trkId]  += 1;

    // ── Get process name ──────────────────────────────────────────────────────
    std::string procName = "Unknown";
    const G4VProcess* proc = step->GetPostStepPoint()->GetProcessDefinedStep();
    if (proc) procName = proc->GetProcessName();

    // ── Build StepData ────────────────────────────────────────────────────────
    StepData s;
    s.event_id    = fEventAction->GetSummary().event_id;
    s.track_id    = trkId;
    s.parent_id   = track->GetParentID();
    s.step_num    = fStepCount[trkId];
    strncpy(s.particle, pname.c_str(), 15); s.particle[15] = '\0';
    s.x           = pos.x() / mm;
    s.y           = pos.y() / mm;
    s.z           = pos.z() / mm;
    s.px          = mom.x() / GeV;
    s.py          = mom.y() / GeV;
    s.pz          = mom.z() / GeV;
    s.p_mag       = p_mag;
    s.KE          = KE;
    s.edep        = edep;
    s.step_len    = stepLen;
    s.global_time = gtime;
    s.beta        = beta;
    s.gamma       = gamma_v;
    s.cher_this_step = cher_this;
    s.cher_cumul  = fCherCumul[trkId];
    s.track_len   = fTrackLen[trkId];
    s.process     = procName;

    fEventAction->RecordStep(s);

    // ── Update event summary accumulators ─────────────────────────────────────
    auto& sum = fEventAction->GetSummary();
    sum.total_edep += edep;

    if (is_pi) {
        sum.pi_cher_total  = fCherCumul[trkId];
        sum.pi_track_len   = fTrackLen[trkId];
        sum.pi_nsteps      = fStepCount[trkId];
    } else if (is_mu) {
        sum.mu_cher_total  = fCherCumul[trkId];
        sum.mu_track_len   = fTrackLen[trkId];
        sum.mu_nsteps      = fStepCount[trkId];
    } else if (is_e) {
        sum.e_cher_total   = fCherCumul[trkId];
        sum.e_track_len    = fTrackLen[trkId];
        sum.e_nsteps       = fStepCount[trkId];
    }
}
